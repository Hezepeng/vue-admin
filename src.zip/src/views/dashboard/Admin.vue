<template>

</template>

<script>
export default {
  name: "Admin",

  data () {
    return {};
  },

  mounted: function() {

  },

  methods: {}
};
</script>

<style scoped>

</style>

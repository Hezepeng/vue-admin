<template>

</template>

<script>
export default {
  name: "Person",

  data () {
    return {};
  },

  mounted: function() {

  },

  methods: {}
};
</script>

<style scoped>

</style>

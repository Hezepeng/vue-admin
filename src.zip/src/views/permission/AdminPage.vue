<template>
  <p>这是AdminPage，需要admin权限才能进入</p>
</template>

<script>
export default {
  name: 'AdminPage'

}
</script>

<style scoped>

</style>
